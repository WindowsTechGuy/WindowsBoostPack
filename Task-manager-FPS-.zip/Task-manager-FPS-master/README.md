## Usage
To set 60 fps in Windows 10 Task manager run:
```bash
FPS.exe 60
```